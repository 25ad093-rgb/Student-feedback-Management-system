# Student Feedback System

A DBMS mini-project built with Python Flask and SQLite.

## Features
- Student and Admin login
- Student feedback submission
- 1–5 rating system
- Comments
- Student management
- Course/faculty management
- Feedback history
- Course-wise feedback report
- Dashboard statistics
- SQLite relational database with primary keys, foreign keys, constraints and joins

## Demo Login
Admin:
- Username: admin
- Password: admin123

Student:
- Username: student
- Password: student123

## Run in VS Code
Open the project folder in VS Code terminal and run:

```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
py app.py
```

Then open:
http://127.0.0.1:5000

The SQLite database file `student_feedback.db` is created automatically on first run.
