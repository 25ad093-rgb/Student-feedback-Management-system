from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "student-feedback-system-secret-key"
DB = "student_feedback.db"

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'student'
    );

    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        register_no TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        department TEXT NOT NULL,
        year INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS courses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_code TEXT UNIQUE NOT NULL,
        course_name TEXT NOT NULL,
        faculty_name TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        course_id INTEGER NOT NULL,
        rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
        comments TEXT,
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(student_id, course_id),
        FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE
    );
    """)

    # Demo accounts
    if not conn.execute("SELECT 1 FROM users WHERE username='admin'").fetchone():
        conn.execute(
            "INSERT INTO users(username,password,role) VALUES(?,?,?)",
            ("admin", generate_password_hash("admin123"), "admin")
        )
    if not conn.execute("SELECT 1 FROM users WHERE username='student'").fetchone():
        conn.execute(
            "INSERT INTO users(username,password,role) VALUES(?,?,?)",
            ("student", generate_password_hash("student123"), "student")
        )

    if conn.execute("SELECT COUNT(*) FROM students").fetchone()[0] == 0:
        conn.executemany(
            "INSERT INTO students(register_no,name,email,department,year) VALUES(?,?,?,?,?)",
            [
                ("23CS001", "Arun Kumar", "arun@example.com", "Computer Science", 3),
                ("23CS002", "Divya S", "divya@example.com", "Computer Science", 3),
                ("23IT003", "Kavin R", "kavin@example.com", "Information Technology", 2)
            ]
        )

    if conn.execute("SELECT COUNT(*) FROM courses").fetchone()[0] == 0:
        conn.executemany(
            "INSERT INTO courses(course_code,course_name,faculty_name) VALUES(?,?,?)",
            [
                ("CS301", "Database Management Systems", "Dr. Priya"),
                ("CS302", "Operating Systems", "Dr. Kumar"),
                ("CS303", "Computer Networks", "Ms. Anitha"),
                ("CS304", "Web Technologies", "Mr. Raj")
            ]
        )
    conn.commit()
    conn.close()

def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                flash("You do not have permission to access that page.", "danger")
                return redirect(url_for("dashboard"))
            return f(*args, **kwargs)
        return wrapper
    return decorator

@app.route("/")
def index():
    return redirect(url_for("dashboard")) if "user_id" in session else redirect(url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required()
def dashboard():
    conn = get_db()
    stats = {
        "students": conn.execute("SELECT COUNT(*) FROM students").fetchone()[0],
        "courses": conn.execute("SELECT COUNT(*) FROM courses").fetchone()[0],
        "feedback": conn.execute("SELECT COUNT(*) FROM feedback").fetchone()[0],
        "average": conn.execute("SELECT ROUND(AVG(rating),2) FROM feedback").fetchone()[0] or 0
    }
    recent = conn.execute("""
        SELECT f.*, s.name student_name, c.course_name
        FROM feedback f
        JOIN students s ON s.id=f.student_id
        JOIN courses c ON c.id=f.course_id
        ORDER BY f.submitted_at DESC LIMIT 5
    """).fetchall()
    conn.close()
    return render_template("dashboard.html", stats=stats, recent=recent)

@app.route("/feedback", methods=["GET","POST"])
@login_required("student")
def feedback():
    conn = get_db()
    students = conn.execute("SELECT * FROM students ORDER BY name").fetchall()
    courses = conn.execute("SELECT * FROM courses ORDER BY course_code").fetchall()
    if request.method == "POST":
        try:
            student_id = int(request.form["student_id"])
            course_id = int(request.form["course_id"])
            rating = int(request.form["rating"])
            comments = request.form.get("comments","").strip()
            conn.execute("""
                INSERT INTO feedback(student_id,course_id,rating,comments)
                VALUES(?,?,?,?)
            """, (student_id,course_id,rating,comments))
            conn.commit()
            flash("Feedback submitted successfully.", "success")
            conn.close()
            return redirect(url_for("my_feedback"))
        except sqlite3.IntegrityError:
            flash("Feedback for this student and course already exists.", "danger")
        except (ValueError, KeyError):
            flash("Please enter valid feedback details.", "danger")
    conn.close()
    return render_template("feedback_form.html", students=students, courses=courses)

@app.route("/my-feedback")
@login_required()
def my_feedback():
    conn = get_db()
    rows = conn.execute("""
        SELECT f.*, s.register_no, s.name student_name, c.course_code,
               c.course_name, c.faculty_name
        FROM feedback f
        JOIN students s ON s.id=f.student_id
        JOIN courses c ON c.id=f.course_id
        ORDER BY f.submitted_at DESC
    """).fetchall()
    conn.close()
    return render_template("feedback_list.html", rows=rows)

@app.route("/students", methods=["GET","POST"])
@login_required("admin")
def students():
    conn = get_db()
    if request.method == "POST":
        try:
            conn.execute("""
                INSERT INTO students(register_no,name,email,department,year)
                VALUES(?,?,?,?,?)
            """, (
                request.form["register_no"].strip(),
                request.form["name"].strip(),
                request.form["email"].strip(),
                request.form["department"].strip(),
                int(request.form["year"])
            ))
            conn.commit()
            flash("Student added.", "success")
        except sqlite3.IntegrityError:
            flash("Register number already exists.", "danger")
        except ValueError:
            flash("Year must be a number.", "danger")
    rows = conn.execute("SELECT * FROM students ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("students.html", students=rows)

@app.route("/students/delete/<int:id>", methods=["POST"])
@login_required("admin")
def delete_student(id):
    conn = get_db()
    conn.execute("DELETE FROM students WHERE id=?", (id,))
    conn.commit()
    conn.close()
    flash("Student deleted.", "success")
    return redirect(url_for("students"))

@app.route("/courses", methods=["GET","POST"])
@login_required("admin")
def courses():
    conn = get_db()
    if request.method == "POST":
        try:
            conn.execute("""
                INSERT INTO courses(course_code,course_name,faculty_name)
                VALUES(?,?,?)
            """, (
                request.form["course_code"].strip(),
                request.form["course_name"].strip(),
                request.form["faculty_name"].strip()
            ))
            conn.commit()
            flash("Course added.", "success")
        except sqlite3.IntegrityError:
            flash("Course code already exists.", "danger")
    rows = conn.execute("SELECT * FROM courses ORDER BY course_code").fetchall()
    conn.close()
    return render_template("courses.html", courses=rows)

@app.route("/courses/delete/<int:id>", methods=["POST"])
@login_required("admin")
def delete_course(id):
    conn = get_db()
    conn.execute("DELETE FROM courses WHERE id=?", (id,))
    conn.commit()
    conn.close()
    flash("Course deleted.", "success")
    return redirect(url_for("courses"))

@app.route("/reports")
@login_required("admin")
def reports():
    conn = get_db()
    report = conn.execute("""
        SELECT c.course_code, c.course_name, c.faculty_name,
               COUNT(f.id) feedback_count,
               ROUND(AVG(f.rating),2) average_rating
        FROM courses c
        LEFT JOIN feedback f ON f.course_id=c.id
        GROUP BY c.id
        ORDER BY average_rating DESC
    """).fetchall()
    conn.close()
    return render_template("reports.html", report=report)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
