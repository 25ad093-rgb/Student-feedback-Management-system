-- Student Feedback System database design
PRAGMA foreign_keys = ON;

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL
);

CREATE TABLE students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    register_no TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    department TEXT NOT NULL,
    year INTEGER NOT NULL
);

CREATE TABLE courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_code TEXT UNIQUE NOT NULL,
    course_name TEXT NOT NULL,
    faculty_name TEXT NOT NULL
);

CREATE TABLE feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    course_id INTEGER NOT NULL,
    rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
    comments TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, course_id),
    FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- Important DBMS queries used by the application:
-- Average rating:
-- SELECT AVG(rating) FROM feedback;
--
-- Join feedback with student and course:
-- SELECT s.name, c.course_name, f.rating, f.comments
-- FROM feedback f
-- JOIN students s ON s.id=f.student_id
-- JOIN courses c ON c.id=f.course_id;
--
-- Course-wise report:
-- SELECT c.course_name, COUNT(f.id), AVG(f.rating)
-- FROM courses c LEFT JOIN feedback f ON c.id=f.course_id
-- GROUP BY c.id;
